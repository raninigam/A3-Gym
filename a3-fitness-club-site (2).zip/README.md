# A3 Fitness Club — Static Website

A fully static single-page marketing site for **A3 Fitness Club**, Indore (Scheme 103) — built with plain HTML, CSS and vanilla JavaScript. There is **no server-side backend / database / build step required**. The entire site runs from a single `index.html` file plus the `images/` folder and supporting static assets.

## 📁 Project structure

```
a3-gym-site/
├── index.html         ← the entire single-page website
├── 404.html           ← custom "Not Found" page
├── favicon.svg        ← site icon (red A3 mark)
├── robots.txt         ← search-engine crawler rules
├── sitemap.xml        ← SEO sitemap
├── .htaccess          ← Apache/cPanel config (cache, gzip, SPA fallback, security headers)
├── netlify.toml       ← Netlify hosting config
├── vercel.json        ← Vercel hosting config
├── _redirects         ← Netlify / Cloudflare Pages SPA fallback
├── _headers           ← extra headers file
├── .gitignore
└── images/
    ├── floor.webp     ← real photo: main gym floor
    ├── cycling.webp   ← real photo: spin bike
    └── promo.webp     ← A3 branded promo creative
```

## 🚀 How to deploy (any static host)

Because there is **zero backend code**, this works on *any* "custom code website" / static hosting option:

### Option 1 — cPanel / Apache shared hosting (Hostinger, BigRock, GoDaddy, Bluehost, HostGator, etc.)
1. ZIP the **contents** of this folder (not the folder itself — i.e. `index.html`, `images/`, `.htaccess`, etc. should be at the root of the ZIP).
2. Open your hosting **File Manager**, navigate to `public_html` (or `htdocs` / `www`).
3. Upload the ZIP, then **Extract** it there.
4. Visit your domain — done. HTTPS/caching/gzip/security headers are handled by `.htaccess`.

### Option 2 — Netlify
- Drag-and-drop this folder onto [app.netlify.com/drop](https://app.netlify.com/drop), or
- Connect the Git repo. The included `netlify.toml` + `_redirects` handle everything automatically.

### Option 3 — Vercel
- `vercel deploy` from inside this folder, or import the Git repo. `vercel.json` handles routing/caching.

### Option 4 — Cloudflare Pages / GitHub Pages / Render / Surge / Firebase Hosting
- Upload / connect the folder as-is. `index.html` is the entry point; `_redirects` handles SPA fallback for Cloudflare Pages.

### Option 5 — Any other host (S3 + CloudFront, Nginx, IIS, etc.)
- Serve the folder as a static site with `index.html` as the default document.
- Set a fallback/rewrite so unknown paths return `index.html` (for anchor links like `#programs`).
- Add cache headers: long cache for images/CSS/JS; no cache for HTML.

## ⚙️ No backend required

The site is 100% client-side:
- All styling is inline CSS (no external CSS framework).
- All scripts are inline vanilla JS (no npm / build step).
- The only external resources are **Google Fonts** (typography) and the embedded **Google Maps iframe** pointing to A3 Fitness Club.
- The phone numbers (`tel:+919926039888`) and email (`mailto:...`) links are native browser actions.

If you later want to add a contact form, you can plug in a service like Formspree, Getform, Web3Forms, Netlify Forms, or Google Forms by swapping the button target — no other code changes are needed.

## 🧪 Local preview

No server required — just double-click `index.html`. If you want the Google Map to load with proper `https://` context, run a tiny local server:

```bash
cd a3-gym-site
python3 -m http.server 8080
# then open http://localhost:8080
```

## 📞 Contact info baked into the site

- **A3 Fitness Club**, Vatsalya Avenue, House No. 1, Ariha Enclave, Scheme 103, Indore (MP) 452012
- **Phone:** +91 99260 39888 / +91 88780 08003
- **Email:** a3fitnessclubb@gmail.com
- **Instagram:** @a3_fitnessclub
- **Hours:** Mon–Sat 6 AM – 10 PM; Sunday 8 AM – 1 PM
